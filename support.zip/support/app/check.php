<?php
require 'functions.php';
$action = new Action();
echo $action->admin_log_view($id);
?>