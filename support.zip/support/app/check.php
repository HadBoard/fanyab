<?php
require 'functions.php';
$action = new Action();
echo $action->movie_add(1, 2, 3, 4);
?>