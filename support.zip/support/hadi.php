<pre>
<?php var_dump($_SERVER);